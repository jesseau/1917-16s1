#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "list.h"

void printList(list l) {
    link curr = l->head;
    while (curr != NULL) {
        printf("%d->", curr->value);
        curr = curr->next;
    }
    printf("X\n");
}

int main(int argc, char *argv[]) {
    list l1 = malloc(sizeof(struct _list));
    assert(l1 != NULL);
    l1->head = NULL;

    // test empty list
    printf("l1 before: "); printList(l1);
    partition(l1);
    printf("l1 after: "); printList(l1);
    assert(l1 != NULL);
    assert(l1->head == NULL);

    node n1 = { 4, NULL };
    node n2 = { 3, NULL };
    node n3 = { 5, NULL };
    node n4 = { 0, NULL };
    node n5 = { 9, NULL };
    node n6 = { 4, NULL };
    node n7 = { 5, NULL };
    node n8 = { 2, NULL };

    l1->head = &n1;
    // test 1 element
    printf("l1 before: "); printList(l1);
    partition(l1);
    printf("l1 after: "); printList(l1);
    assert(l1 != NULL);
    assert(l1->head->value == 4);
    assert(l1->head->next == NULL);

    n1.next = &n2;
    printf("l1 before: "); printList(l1);
    partition(l1);
    printf("l1 after: "); printList(l1);
    assert(l1 != NULL);
    assert(l1->head->value == 3);
    assert(l1->head->next->value == 4);
    assert(l1->head->next->next == NULL);

    // 3 0 2 4 5 9 4 5
    l1->head = &n1;
    n1.next = &n2;
    n2.next = &n3;
    n3.next = &n4;
    n4.next = &n5;
    n5.next = &n6;
    n6.next = &n7;
    n7.next = &n8;
    n8.next = NULL;
    printf("l1 before: "); printList(l1);
    partition(l1);
    printf("l1 after: "); printList(l1);
    assert(l1 != NULL);
    link nc = l1->head;
    assert(nc->value == 3); nc = nc->next;
    assert(nc->value == 0); nc = nc->next;
    assert(nc->value == 2); nc = nc->next;
    assert(nc->value == 4); nc = nc->next;
    assert(nc->value == 5); nc = nc->next;
    assert(nc->value == 9); nc = nc->next;
    assert(nc->value == 4); nc = nc->next;
    assert(nc->value == 5); nc = nc->next;
    assert(nc == NULL);

    l1->head = &n1;
    n1.next = &n2; n1.value = 1;
    n2.next = &n3; n2.value = 2;
    n3.next = &n4; n3.value = 3;
    n4.next = &n5; n4.value = 4;
    n5.next = &n6; n5.value = 5;
    n6.next = &n7; n6.value = 6;
    n7.next = &n8; n7.value = 7;
    n8.next = NULL; n8.value = 8;
    printf("l1 before: "); printList(l1);
    partition(l1);
    printf("l1 after: "); printList(l1);
    assert(l1 != NULL);
    nc = l1->head;
    assert(nc->value == 1); nc = nc->next;
    assert(nc->value == 2); nc = nc->next;
    assert(nc->value == 3); nc = nc->next;
    assert(nc->value == 4); nc = nc->next;
    assert(nc->value == 5); nc = nc->next;
    assert(nc->value == 6); nc = nc->next;
    assert(nc->value == 7); nc = nc->next;
    assert(nc->value == 8); nc = nc->next;
    assert(nc == NULL);

    free(l1);
    printf("all tests passed\n");
    return EXIT_SUCCESS;
}
